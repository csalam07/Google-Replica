export const key = "AIzaSyDLE6nXidBuyRvzus0b_AzCi1P9ntcXrv4";
export const cx ="b5cdef1eaf06e8dfe"; 